
function main() {

(function () {
   'use strict';
    
    // Toggling the Services options button on the Services page
    $('#a1').click(function(){
        $(this).toggleClass('class2');
    });

}());

}
main();